package uk.ac.soton.ecs.db5n17.ch1;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigourous Test :-)
     */
	@Test
    public void testApp() {
        assertTrue( true );
    }
}
